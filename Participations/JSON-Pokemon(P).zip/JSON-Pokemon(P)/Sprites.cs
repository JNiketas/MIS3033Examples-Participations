﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JSON_Pokemon_P_
{
    class Sprites
    {
        public List<Sprite> sprites { get; set; }

    }

    public class Sprite
    {
        public string front_default { get; set; }
    }
}
